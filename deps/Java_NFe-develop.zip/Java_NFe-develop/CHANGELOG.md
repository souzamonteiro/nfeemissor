# Notas de versão
- Correcao Manifestacao