package br.com.swconsultoria.nfe.dom.enuns;

/**
 * @author Samuel Oliveira - samuk.exe@hotmail.com
 * Data: 02/03/2019 - 20:04
 */
public enum PessoaEnum {
    FISICA,
    JURIDICA
}
